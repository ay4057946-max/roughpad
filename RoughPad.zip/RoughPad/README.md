# Rough Pad - floating rough page for online tests

Build: put this ZIP + .github/workflows/build.yml in a GitHub repo. The workflow unzips it and builds a debug APK
(Actions tab -> latest run -> Artifacts -> RoughPad-APK).
