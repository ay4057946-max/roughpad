package com.roughpad.app;

import android.content.Context;
import android.graphics.Bitmap;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Local storage. Everything older than 90 days is deleted automatically. */
public class StorageManager {
    public static final long RETENTION_DAYS = 90L;
    public static final long RETENTION_MS = RETENTION_DAYS * 24L * 60L * 60L * 1000L;

    public static class Session {
        public long id;
        public final TreeMap<Integer, File> pages = new TreeMap<>();
    }

    private static File sessionsDir(Context c) {
        File d = new File(c.getFilesDir(), "sessions");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private static File currentFile(Context c) {
        return new File(c.getFilesDir(), "current.json");
    }

    // ---------- current (auto-saved) work ----------

    public static void saveCurrent(Context c, String json) {
        try {
            writeText(currentFile(c), json);
        } catch (Exception ignored) {
        }
    }

    public static String loadCurrent(Context c) {
        File f = currentFile(c);
        if (!f.exists()) return null;
        if (System.currentTimeMillis() - f.lastModified() > RETENTION_MS) {
            f.delete();
            return null;
        }
        try {
            return readText(f);
        } catch (Exception e) {
            return null;
        }
    }

    public static void clearCurrent(Context c) {
        File f = currentFile(c);
        if (f.exists()) f.delete();
    }

    // ---------- history sessions ----------

    public static long saveSession(Context c, String json, List<Bitmap> pages) {
        long id = System.currentTimeMillis();
        File dir = sessionsDir(c);
        try {
            writeText(new File(dir, "s_" + id + ".json"), json);
        } catch (Exception ignored) {
        }
        for (int i = 0; i < pages.size(); i++) {
            try {
                FileOutputStream fo = new FileOutputStream(new File(dir, "s_" + id + "_" + (i + 1) + ".png"));
                pages.get(i).compress(Bitmap.CompressFormat.PNG, 100, fo);
                fo.close();
            } catch (Exception ignored) {
            }
        }
        return id;
    }

    public static List<Session> listSessions(Context c) {
        File[] files = sessionsDir(c).listFiles();
        TreeMap<Long, Session> map = new TreeMap<>(Collections.reverseOrder());
        Pattern pat = Pattern.compile("s_(\\d+)_(\\d+)\\.png");
        if (files != null) {
            for (File f : files) {
                Matcher m = pat.matcher(f.getName());
                if (!m.matches()) continue;
                long id = Long.parseLong(m.group(1));
                int idx = Integer.parseInt(m.group(2));
                Session s = map.get(id);
                if (s == null) {
                    s = new Session();
                    s.id = id;
                    map.put(id, s);
                }
                s.pages.put(idx, f);
            }
        }
        return new ArrayList<>(map.values());
    }

    public static void deleteSession(Context c, long id) {
        File[] files = sessionsDir(c).listFiles();
        if (files == null) return;
        for (File f : files) {
            String n = f.getName();
            if (n.equals("s_" + id + ".json") || n.startsWith("s_" + id + "_")) f.delete();
        }
    }

    public static void deleteAllSessions(Context c) {
        File[] files = sessionsDir(c).listFiles();
        if (files == null) return;
        for (File f : files) f.delete();
    }

    /** Removes anything older than 90 days. */
    public static void purgeOld(Context c) {
        long now = System.currentTimeMillis();
        File[] files = sessionsDir(c).listFiles();
        if (files != null) {
            for (File f : files) {
                if (now - f.lastModified() > RETENTION_MS) f.delete();
            }
        }
        File cur = currentFile(c);
        if (cur.exists() && now - cur.lastModified() > RETENTION_MS) cur.delete();
    }

    public static int daysLeft(long id) {
        long age = System.currentTimeMillis() - id;
        long left = RETENTION_DAYS - age / (24L * 60L * 60L * 1000L);
        return (int) Math.max(0, left);
    }

    // ---------- helpers ----------

    private static void writeText(File f, String s) throws Exception {
        FileOutputStream fo = new FileOutputStream(f);
        fo.write(s.getBytes(StandardCharsets.UTF_8));
        fo.close();
    }

    private static String readText(File f) throws Exception {
        InputStream in = new FileInputStream(f);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int r;
        while ((r = in.read(buf)) != -1) bo.write(buf, 0, r);
        in.close();
        return new String(bo.toByteArray(), StandardCharsets.UTF_8);
    }
}
