package com.roughpad.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/** Multi-page drawing canvas with tools, undo/redo and paper styles. */
public class DrawingView extends View {

    public interface Listener {
        void onChanged();

        void onPageChanged(int index, int count);
    }

    static class Page {
        ArrayList<Stroke> strokes = new ArrayList<>();
        int paper = 0;
        final ArrayList<ArrayList<Stroke>> undo = new ArrayList<>();
        final ArrayList<ArrayList<Stroke>> redo = new ArrayList<>();
    }

    public static final String[] PAPER_NAMES = {"Plain", "Ruled", "Grid", "Dots", "Yellow"};

    private final ArrayList<Page> pages = new ArrayList<>();
    private int cur = 0;
    private int tool = Stroke.PEN;
    private int color = Color.BLACK;
    private float brush;
    private int paperAlpha = 255;
    private final float density;

    private Bitmap base;
    private Canvas baseCanvas;
    private Stroke current;
    private Path currentPath;
    private Paint currentPaint;
    private boolean erasedGesture = false;
    private Listener listener;

    public DrawingView(Context context) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;
        setBrushLevel(6);
        pages.add(new Page());
    }

    public void setListener(Listener l) {
        listener = l;
    }

    private Page page() {
        return pages.get(cur);
    }

    // ---------- settings ----------

    public void setTool(int t) {
        tool = t;
    }

    public int getTool() {
        return tool;
    }

    public void setColor(int c) {
        color = c;
    }

    public void setBrushLevel(int level) {
        brush = Math.max(1, level) * density * 0.6f;
    }

    public void setPaperAlpha(int a) {
        paperAlpha = Math.max(0, Math.min(255, a));
        invalidate();
    }

    public String paperName() {
        return PAPER_NAMES[page().paper];
    }

    public String cyclePaper() {
        Page p = page();
        p.paper = (p.paper + 1) % PAPER_NAMES.length;
        invalidate();
        notifyChanged();
        return PAPER_NAMES[p.paper];
    }

    // ---------- history ----------

    private void pushUndo(Page p) {
        p.undo.add(new ArrayList<>(p.strokes));
        if (p.undo.size() > 100) p.undo.remove(0);
        p.redo.clear();
    }

    public void undo() {
        Page p = page();
        if (p.undo.isEmpty()) return;
        p.redo.add(new ArrayList<>(p.strokes));
        p.strokes = p.undo.remove(p.undo.size() - 1);
        rebuild();
        notifyChanged();
    }

    public void redo() {
        Page p = page();
        if (p.redo.isEmpty()) return;
        p.undo.add(new ArrayList<>(p.strokes));
        p.strokes = p.redo.remove(p.redo.size() - 1);
        rebuild();
        notifyChanged();
    }

    public void clearPage() {
        Page p = page();
        if (p.strokes.isEmpty()) return;
        pushUndo(p);
        p.strokes = new ArrayList<>();
        rebuild();
        notifyChanged();
    }

    public void reset() {
        pages.clear();
        pages.add(new Page());
        cur = 0;
        current = null;
        rebuild();
        firePage();
        notifyChanged();
    }

    public boolean hasContent() {
        for (Page p : pages) {
            if (!p.strokes.isEmpty()) return true;
        }
        return false;
    }

    // ---------- pages ----------

    public void newPage() {
        pages.add(cur + 1, new Page());
        cur++;
        rebuild();
        firePage();
        notifyChanged();
    }

    public void nextPage() {
        if (cur < pages.size() - 1) {
            cur++;
            rebuild();
            firePage();
        }
    }

    public void prevPage() {
        if (cur > 0) {
            cur--;
            rebuild();
            firePage();
        }
    }

    private void firePage() {
        if (listener != null) listener.onPageChanged(cur, pages.size());
    }

    private void notifyChanged() {
        if (listener != null) listener.onChanged();
    }

    // ---------- rendering ----------

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w <= 0 || h <= 0) return;
        Bitmap nb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        if (base != null) base.recycle();
        base = nb;
        baseCanvas = new Canvas(base);
        rebuild();
    }

    private void rebuild() {
        if (baseCanvas == null) return;
        base.eraseColor(Color.TRANSPARENT);
        for (Stroke s : page().strokes) drawStroke(baseCanvas, s);
        invalidate();
    }

    private static void drawStroke(Canvas c, Stroke s) {
        c.drawPath(s.buildPath(), s.makePaint());
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        drawPaper(canvas, w, h, page().paper, paperAlpha, density);
        int sc = canvas.saveLayer(0f, 0f, (float) w, (float) h, null);
        if (base != null) canvas.drawBitmap(base, 0f, 0f, null);
        if (current != null && currentPath != null && currentPaint != null) {
            canvas.drawPath(currentPath, currentPaint);
        }
        canvas.restoreToCount(sc);
    }

    static void drawPaper(Canvas c, int w, int h, int type, int alpha, float d) {
        if (type == 4) c.drawColor(Color.argb(alpha, 255, 249, 196));
        else c.drawColor(Color.argb(alpha, 255, 255, 255));
        int la = Math.min(255, alpha * 150 / 255);
        Paint lp = new Paint();
        lp.setStrokeWidth(Math.max(1f, d * 0.8f));
        if (type == 1 || type == 4) {
            lp.setColor(Color.argb(la, 100, 140, 200));
            float sp = d * 30f;
            for (float y = sp + d * 10f; y < h; y += sp) c.drawLine(0f, y, (float) w, y, lp);
            if (type == 1) {
                lp.setColor(Color.argb(la, 230, 90, 90));
                c.drawLine(d * 40f, 0f, d * 40f, (float) h, lp);
            }
        } else if (type == 2) {
            lp.setColor(Color.argb(la, 150, 170, 190));
            float sp = d * 24f;
            for (float y = sp; y < h; y += sp) c.drawLine(0f, y, (float) w, y, lp);
            for (float x = sp; x < w; x += sp) c.drawLine(x, 0f, x, (float) h, lp);
        } else if (type == 3) {
            lp.setStyle(Paint.Style.FILL);
            lp.setAntiAlias(true);
            lp.setColor(Color.argb(la, 110, 120, 140));
            float sp = d * 24f;
            for (float y = sp; y < h; y += sp) {
                for (float x = sp; x < w; x += sp) c.drawCircle(x, y, d * 1.2f, lp);
            }
        }
    }

    // ---------- touch ----------

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX();
        float y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                if (tool == Stroke.STROKE_ERASER) {
                    erasedGesture = false;
                    strokeErase(x, y);
                } else {
                    current = new Stroke(tool, color, brush);
                    currentPaint = current.makePaint();
                    addPoint(x, y);
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getHistorySize(); i++) {
                    movePoint(e.getHistoricalX(i), e.getHistoricalY(i));
                }
                movePoint(x, y);
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (tool != Stroke.STROKE_ERASER) {
                    addPoint(x, y);
                    commit();
                }
                invalidate();
                return true;
            default:
                return true;
        }
    }

    private void movePoint(float x, float y) {
        if (tool == Stroke.STROKE_ERASER) strokeErase(x, y);
        else addPoint(x, y);
    }

    private void addPoint(float x, float y) {
        if (current == null) return;
        current.add(x, y);
        currentPath = current.buildPath();
    }

    private void commit() {
        if (current == null) return;
        Stroke s = current;
        current = null;
        currentPath = null;
        currentPaint = null;
        if (s.isShape() && s.n < 2) return;
        Page p = page();
        pushUndo(p);
        p.strokes.add(s);
        if (baseCanvas != null) drawStroke(baseCanvas, s);
        notifyChanged();
    }

    private void strokeErase(float x, float y) {
        Page p = page();
        float r = 12f * density;
        boolean any = false;
        for (int i = p.strokes.size() - 1; i >= 0; i--) {
            Stroke s = p.strokes.get(i);
            if (s.tool != Stroke.ERASER && s.hits(x, y, r)) {
                if (!erasedGesture) {
                    pushUndo(p);
                    erasedGesture = true;
                }
                p.strokes.remove(i);
                any = true;
            }
        }
        if (any) {
            rebuild();
            notifyChanged();
        }
    }

    // ---------- export / import ----------

    public ArrayList<Bitmap> renderAllPages() {
        float maxX = 0f;
        float maxY = 0f;
        for (Page pg : pages) {
            for (Stroke s : pg.strokes) {
                for (int i = 0; i < s.n; i++) {
                    maxX = Math.max(maxX, s.xy[2 * i]);
                    maxY = Math.max(maxY, s.xy[2 * i + 1]);
                }
            }
        }
        int w = Math.max(Math.max(getWidth(), 480), Math.min(4000, (int) maxX + 20));
        int h = Math.max(Math.max(getHeight(), 640), Math.min(4000, (int) maxY + 20));
        ArrayList<Bitmap> out = new ArrayList<>();
        for (Page pg : pages) {
            Bitmap layer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas lc = new Canvas(layer);
            for (Stroke s : pg.strokes) drawStroke(lc, s);
            Bitmap result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas oc = new Canvas(result);
            drawPaper(oc, w, h, pg.paper, 255, density);
            oc.drawBitmap(layer, 0f, 0f, null);
            layer.recycle();
            out.add(result);
        }
        return out;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("cur", cur);
        JSONArray pa = new JSONArray();
        for (Page p : pages) {
            JSONObject po = new JSONObject();
            po.put("paper", p.paper);
            JSONArray sa = new JSONArray();
            for (Stroke s : p.strokes) {
                JSONObject so = new JSONObject();
                so.put("t", s.tool);
                so.put("c", s.color);
                so.put("w", (double) s.width);
                JSONArray pts = new JSONArray();
                for (int i = 0; i < s.n * 2; i++) {
                    pts.put(Math.round(s.xy[i] * 10f) / 10.0);
                }
                so.put("p", pts);
                sa.put(so);
            }
            po.put("strokes", sa);
            pa.put(po);
        }
        o.put("pages", pa);
        return o;
    }

    public boolean loadJson(String s) {
        try {
            JSONObject o = new JSONObject(s);
            JSONArray pa = o.getJSONArray("pages");
            ArrayList<Page> np = new ArrayList<>();
            for (int i = 0; i < pa.length(); i++) {
                JSONObject po = pa.getJSONObject(i);
                Page p = new Page();
                p.paper = Math.max(0, Math.min(PAPER_NAMES.length - 1, po.optInt("paper", 0)));
                JSONArray sa = po.getJSONArray("strokes");
                for (int j = 0; j < sa.length(); j++) {
                    JSONObject so = sa.getJSONObject(j);
                    Stroke st = new Stroke(so.getInt("t"), so.getInt("c"), (float) so.getDouble("w"));
                    JSONArray pts = so.getJSONArray("p");
                    for (int k = 0; k + 1 < pts.length(); k += 2) {
                        st.add((float) pts.getDouble(k), (float) pts.getDouble(k + 1));
                    }
                    p.strokes.add(st);
                }
                np.add(p);
            }
            if (np.isEmpty()) np.add(new Page());
            pages.clear();
            pages.addAll(np);
            cur = Math.max(0, Math.min(pages.size() - 1, o.optInt("cur", 0)));
            rebuild();
            firePage();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
