package com.roughpad.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Multi-page drawing canvas with tools, undo/redo, paper styles.
 * One finger draws. Two fingers scroll (pan) and pinch-zoom the page.
 * Strokes are stored in "world" coordinates; screen = world * scale + offset.
 */
public class DrawingView extends View {

    public interface Listener {
        void onChanged();

        void onPageChanged(int index, int count);
    }

    static class Page {
        ArrayList<Stroke> strokes = new ArrayList<>();
        int paper = 0;
        final ArrayList<ArrayList<Stroke>> undo = new ArrayList<>();
        final ArrayList<ArrayList<Stroke>> redo = new ArrayList<>();
    }

    public static final String[] PAPER_NAMES = {"Plain", "Ruled", "Grid", "Dots", "Yellow"};
    private static final float MIN_SCALE = 0.4f;
    private static final float MAX_SCALE = 4f;

    private final ArrayList<Page> pages = new ArrayList<>();
    private int cur = 0;
    private int tool = Stroke.PEN;
    private int color = Color.BLACK;
    private float brush;
    private int paperAlpha = 255;
    private final float density;

    // view transform
    private float scale = 1f;
    private float ox = 0f;
    private float oy = 0f;

    // gesture state
    private boolean navigating = false;
    private boolean ignoring = false;
    private float lastCx, lastCy, lastDist;

    private Stroke current;
    private Path currentPath;
    private Paint currentPaint;
    private boolean erasedGesture = false;
    private Listener listener;

    public DrawingView(Context context) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;
        setBrushLevel(6);
        pages.add(new Page());
    }

    public void setListener(Listener l) {
        listener = l;
    }

    private Page page() {
        return pages.get(cur);
    }

    // ---------- settings ----------

    public void setTool(int t) {
        tool = t;
    }

    public int getTool() {
        return tool;
    }

    public void setColor(int c) {
        color = c;
    }

    public void setBrushLevel(int level) {
        brush = Math.max(1, level) * density * 0.6f;
    }

    public void setPaperAlpha(int a) {
        paperAlpha = Math.max(0, Math.min(255, a));
        invalidate();
    }

    public String paperName() {
        return PAPER_NAMES[page().paper];
    }

    public String cyclePaper() {
        Page p = page();
        p.paper = (p.paper + 1) % PAPER_NAMES.length;
        invalidate();
        notifyChanged();
        return PAPER_NAMES[p.paper];
    }

    /** Back to 100% zoom at the page origin. */
    public void resetView() {
        scale = 1f;
        ox = 0f;
        oy = 0f;
        invalidate();
    }

    // ---------- history ----------

    private void pushUndo(Page p) {
        p.undo.add(new ArrayList<>(p.strokes));
        if (p.undo.size() > 100) p.undo.remove(0);
        p.redo.clear();
    }

    public void undo() {
        Page p = page();
        if (p.undo.isEmpty()) return;
        p.redo.add(new ArrayList<>(p.strokes));
        p.strokes = p.undo.remove(p.undo.size() - 1);
        invalidate();
        notifyChanged();
    }

    public void redo() {
        Page p = page();
        if (p.redo.isEmpty()) return;
        p.undo.add(new ArrayList<>(p.strokes));
        p.strokes = p.redo.remove(p.redo.size() - 1);
        invalidate();
        notifyChanged();
    }

    public void clearPage() {
        Page p = page();
        if (p.strokes.isEmpty()) return;
        pushUndo(p);
        p.strokes = new ArrayList<>();
        invalidate();
        notifyChanged();
    }

    public void reset() {
        pages.clear();
        pages.add(new Page());
        cur = 0;
        current = null;
        scale = 1f;
        ox = 0f;
        oy = 0f;
        invalidate();
        firePage();
        notifyChanged();
    }

    public boolean hasContent() {
        for (Page p : pages) {
            if (!p.strokes.isEmpty()) return true;
        }
        return false;
    }

    // ---------- pages ----------

    public void newPage() {
        pages.add(cur + 1, new Page());
        cur++;
        invalidate();
        firePage();
        notifyChanged();
    }

    public void nextPage() {
        if (cur < pages.size() - 1) {
            cur++;
            invalidate();
            firePage();
        }
    }

    public void prevPage() {
        if (cur > 0) {
            cur--;
            invalidate();
            firePage();
        }
    }

    private void firePage() {
        if (listener != null) listener.onPageChanged(cur, pages.size());
    }

    private void notifyChanged() {
        if (listener != null) listener.onChanged();
    }

    // ---------- rendering ----------

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        drawPaper(canvas, w, h, page().paper, paperAlpha, density, ox, oy, scale);
        int sc = canvas.saveLayer(0f, 0f, (float) w, (float) h, null);
        canvas.translate(ox, oy);
        canvas.scale(scale, scale);
        for (Stroke s : page().strokes) {
            canvas.drawPath(s.getPath(), s.getPaint());
        }
        if (current != null && currentPath != null && currentPaint != null) {
            canvas.drawPath(currentPath, currentPaint);
        }
        canvas.restoreToCount(sc);
    }

    /** Draws paper background + pattern. screen = world * sc + (ox, oy). */
    static void drawPaper(Canvas c, int w, int h, int type, int alpha, float d, float ox, float oy, float sc) {
        if (type == 4) c.drawColor(Color.argb(alpha, 255, 249, 196));
        else c.drawColor(Color.argb(alpha, 255, 255, 255));
        if (type == 0) return;
        int la = Math.min(255, alpha * 150 / 255);
        c.save();
        c.translate(ox, oy);
        c.scale(sc, sc);
        float x0 = -ox / sc;
        float y0 = -oy / sc;
        float x1 = x0 + w / sc;
        float y1 = y0 + h / sc;
        Paint lp = new Paint();
        lp.setStrokeWidth(Math.max(1f, d * 0.8f) / sc);
        if (type == 1 || type == 4) {
            lp.setColor(Color.argb(la, 100, 140, 200));
            float sp = d * 30f;
            float off = d * 10f;
            float y = (float) Math.floor((y0 - off) / sp) * sp + off;
            for (; y <= y1; y += sp) c.drawLine(x0, y, x1, y, lp);
            if (type == 1) {
                lp.setColor(Color.argb(la, 230, 90, 90));
                float mx = d * 40f;
                if (mx >= x0 && mx <= x1) c.drawLine(mx, y0, mx, y1, lp);
            }
        } else if (type == 2) {
            lp.setColor(Color.argb(la, 150, 170, 190));
            float sp = d * 24f;
            float y = (float) Math.floor(y0 / sp) * sp;
            for (; y <= y1; y += sp) c.drawLine(x0, y, x1, y, lp);
            float x = (float) Math.floor(x0 / sp) * sp;
            for (; x <= x1; x += sp) c.drawLine(x, y0, x, y1, lp);
        } else if (type == 3) {
            lp.setStyle(Paint.Style.FILL);
            lp.setAntiAlias(true);
            lp.setColor(Color.argb(la, 110, 120, 140));
            float sp = d * 24f;
            float ys = (float) Math.floor(y0 / sp) * sp;
            float xs = (float) Math.floor(x0 / sp) * sp;
            for (float y = ys; y <= y1; y += sp) {
                for (float x = xs; x <= x1; x += sp) c.drawCircle(x, y, d * 1.2f, lp);
            }
        }
        c.restore();
    }

    // ---------- touch ----------

    private float wx(float sx) {
        return (sx - ox) / scale;
    }

    private float wy(float sy) {
        return (sy - oy) / scale;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                navigating = false;
                ignoring = false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                if (tool == Stroke.STROKE_ERASER) {
                    erasedGesture = false;
                    strokeErase(wx(e.getX()), wy(e.getY()));
                } else {
                    current = new Stroke(tool, color, brush / scale);
                    currentPaint = current.makePaint();
                    addPoint(wx(e.getX()), wy(e.getY()));
                }
                invalidate();
                return true;

            case MotionEvent.ACTION_POINTER_DOWN:
                if (!navigating) {
                    discardCurrent();
                    navigating = true;
                }
                baseline(e, -1);
                return true;

            case MotionEvent.ACTION_MOVE:
                if (navigating) {
                    if (e.getPointerCount() >= 2) navMove(e);
                    return true;
                }
                if (ignoring) return true;
                for (int i = 0; i < e.getHistorySize(); i++) {
                    movePoint(wx(e.getHistoricalX(i)), wy(e.getHistoricalY(i)));
                }
                movePoint(wx(e.getX()), wy(e.getY()));
                invalidate();
                return true;

            case MotionEvent.ACTION_POINTER_UP:
                if (navigating) {
                    if (e.getPointerCount() - 1 >= 2) {
                        baseline(e, e.getActionIndex());
                    } else {
                        navigating = false;
                        ignoring = true;
                    }
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (!navigating && !ignoring && tool != Stroke.STROKE_ERASER) {
                    addPoint(wx(e.getX()), wy(e.getY()));
                    commit();
                }
                navigating = false;
                ignoring = false;
                invalidate();
                return true;

            default:
                return true;
        }
    }

    private void discardCurrent() {
        current = null;
        currentPath = null;
        currentPaint = null;
        invalidate();
    }

    private void baseline(MotionEvent e, int skip) {
        int a = -1;
        int b = -1;
        for (int i = 0; i < e.getPointerCount(); i++) {
            if (i == skip) continue;
            if (a < 0) a = i;
            else {
                b = i;
                break;
            }
        }
        if (a < 0 || b < 0) return;
        float x0 = e.getX(a), y0 = e.getY(a), x1 = e.getX(b), y1 = e.getY(b);
        lastCx = (x0 + x1) / 2f;
        lastCy = (y0 + y1) / 2f;
        lastDist = (float) Math.hypot(x1 - x0, y1 - y0);
    }

    private void navMove(MotionEvent e) {
        float x0 = e.getX(0), y0 = e.getY(0), x1 = e.getX(1), y1 = e.getY(1);
        float cx = (x0 + x1) / 2f;
        float cy = (y0 + y1) / 2f;
        float dist = (float) Math.hypot(x1 - x0, y1 - y0);
        // world point that was under the previous midpoint
        float worldX = (lastCx - ox) / scale;
        float worldY = (lastCy - oy) / scale;
        float min = 10f * density;
        if (lastDist > min && dist > min) {
            scale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, scale * dist / lastDist));
        }
        // keep that world point under the current midpoint (pan + zoom around fingers)
        ox = cx - worldX * scale;
        oy = cy - worldY * scale;
        lastCx = cx;
        lastCy = cy;
        lastDist = dist;
        invalidate();
    }

    private void movePoint(float x, float y) {
        if (tool == Stroke.STROKE_ERASER) strokeErase(x, y);
        else addPoint(x, y);
    }

    private void addPoint(float x, float y) {
        if (current == null) return;
        current.add(x, y);
        currentPath = current.buildPath();
    }

    private void commit() {
        if (current == null) return;
        Stroke s = current;
        current = null;
        currentPath = null;
        currentPaint = null;
        if (s.isShape() && s.n < 2) return;
        Page p = page();
        pushUndo(p);
        p.strokes.add(s);
        notifyChanged();
    }

    private void strokeErase(float x, float y) {
        Page p = page();
        float r = 12f * density / scale;
        boolean any = false;
        for (int i = p.strokes.size() - 1; i >= 0; i--) {
            Stroke s = p.strokes.get(i);
            if (s.tool != Stroke.ERASER && s.hits(x, y, r)) {
                if (!erasedGesture) {
                    pushUndo(p);
                    erasedGesture = true;
                }
                p.strokes.remove(i);
                any = true;
            }
        }
        if (any) {
            invalidate();
            notifyChanged();
        }
    }

    // ---------- export / import ----------

    public ArrayList<Bitmap> renderAllPages() {
        float minX = 0f;
        float minY = 0f;
        float maxX = Math.max(getWidth(), 480);
        float maxY = Math.max(getHeight(), 640);
        for (Page pg : pages) {
            for (Stroke s : pg.strokes) {
                for (int i = 0; i < s.n; i++) {
                    minX = Math.min(minX, s.xy[2 * i] - 20f);
                    minY = Math.min(minY, s.xy[2 * i + 1] - 20f);
                    maxX = Math.max(maxX, s.xy[2 * i] + 20f);
                    maxY = Math.max(maxY, s.xy[2 * i + 1] + 20f);
                }
            }
        }
        float left = (float) Math.floor(minX);
        float top = (float) Math.floor(minY);
        int w = Math.max(1, Math.min(4000, (int) Math.ceil(maxX - left)));
        int h = Math.max(1, Math.min(4000, (int) Math.ceil(maxY - top)));
        ArrayList<Bitmap> out = new ArrayList<>();
        for (Page pg : pages) {
            Bitmap layer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas lc = new Canvas(layer);
            lc.translate(-left, -top);
            for (Stroke s : pg.strokes) lc.drawPath(s.getPath(), s.getPaint());
            Bitmap result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas oc = new Canvas(result);
            drawPaper(oc, w, h, pg.paper, 255, density, -left, -top, 1f);
            oc.drawBitmap(layer, 0f, 0f, null);
            layer.recycle();
            out.add(result);
        }
        return out;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("cur", cur);
        JSONArray pa = new JSONArray();
        for (Page p : pages) {
            JSONObject po = new JSONObject();
            po.put("paper", p.paper);
            JSONArray sa = new JSONArray();
            for (Stroke s : p.strokes) {
                JSONObject so = new JSONObject();
                so.put("t", s.tool);
                so.put("c", s.color);
                so.put("w", (double) s.width);
                JSONArray pts = new JSONArray();
                for (int i = 0; i < s.n * 2; i++) {
                    pts.put(Math.round(s.xy[i] * 10f) / 10.0);
                }
                so.put("p", pts);
                sa.put(so);
            }
            po.put("strokes", sa);
            pa.put(po);
        }
        o.put("pages", pa);
        return o;
    }

    public boolean loadJson(String s) {
        try {
            JSONObject o = new JSONObject(s);
            JSONArray pa = o.getJSONArray("pages");
            ArrayList<Page> np = new ArrayList<>();
            for (int i = 0; i < pa.length(); i++) {
                JSONObject po = pa.getJSONObject(i);
                Page p = new Page();
                p.paper = Math.max(0, Math.min(PAPER_NAMES.length - 1, po.optInt("paper", 0)));
                JSONArray sa = po.getJSONArray("strokes");
                for (int j = 0; j < sa.length(); j++) {
                    JSONObject so = sa.getJSONObject(j);
                    Stroke st = new Stroke(so.getInt("t"), so.getInt("c"), (float) so.getDouble("w"));
                    JSONArray pts = so.getJSONArray("p");
                    for (int k = 0; k + 1 < pts.length(); k += 2) {
                        st.add((float) pts.getDouble(k), (float) pts.getDouble(k + 1));
                    }
                    p.strokes.add(st);
                }
                np.add(p);
            }
            if (np.isEmpty()) np.add(new Page());
            pages.clear();
            pages.addAll(np);
            cur = Math.max(0, Math.min(pages.size() - 1, o.optInt("cur", 0)));
            invalidate();
            firePage();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
