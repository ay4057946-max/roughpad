package com.roughpad.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HistoryActivity extends Activity {

    private LinearLayout list;
    private Themes.T th;
    private final ExecutorService pool = Executors.newFixedThreadPool(2);

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        th = Themes.current(this);
        getWindow().setStatusBarColor(th.primaryDark);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(th.pageBg);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{th.primary, th.primaryDark}));
        bar.setPadding(dp(16), dp(28), dp(8), dp(10));
        TextView t = new TextView(this);
        t.setText("Saved rough work");
        t.setTextColor(Color.WHITE);
        t.setTextSize(18);
        t.setTypeface(null, Typeface.BOLD);
        bar.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button delAll = new Button(this);
        delAll.setText("Delete all");
        delAll.setAllCaps(false);
        delAll.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setMessage("Delete ALL saved rough work?")
                .setPositiveButton("Delete", (d, w) -> {
                    StorageManager.deleteAllSessions(this);
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show());
        bar.addView(delAll);
        root.addView(bar);

        ScrollView sv = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12), dp(12), dp(12), dp(12));
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onDestroy() {
        pool.shutdownNow();
        super.onDestroy();
    }

    private void refresh() {
        StorageManager.purgeOld(this);
        list.removeAllViews();
        List<StorageManager.Session> sessions = StorageManager.listSessions(this);
        if (sessions.isEmpty()) {
            TextView e = new TextView(this);
            e.setText("Nothing saved yet.\nUse the Save button (or Exit) in the floating Rough Pad to keep your work here for 90 days.");
            e.setTextSize(14);
            e.setTextColor(th.muted);
            e.setPadding(dp(8), dp(24), dp(8), 0);
            list.addView(e);
            return;
        }
        SimpleDateFormat fmt = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault());
        for (StorageManager.Session s : sessions) addRow(s, fmt);
    }

    private void addRow(final StorageManager.Session s, SimpleDateFormat fmt) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(th.card);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), th.chip);
        card.setBackground(bg);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cl.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(cl);

        final ImageView thumb = new ImageView(this);
        thumb.setBackgroundColor(0xFFECEFF1);
        thumb.setScaleType(ImageView.ScaleType.FIT_CENTER);
        card.addView(thumb, new LinearLayout.LayoutParams(dp(90), dp(120)));
        final File first = s.pages.firstEntry().getValue();
        pool.execute(() -> {
            final Bitmap b = decode(first, 240, 1);
            runOnUiThread(() -> {
                if (!isDestroyed() && b != null) thumb.setImageBitmap(b);
            });
        });

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(12), 0, 0, 0);
        TextView date = new TextView(this);
        date.setText(fmt.format(new Date(s.id)));
        date.setTextSize(15);
        date.setTypeface(null, Typeface.BOLD);
        date.setTextColor(th.chipText);
        info.addView(date);
        TextView meta = new TextView(this);
        int n = s.pages.size();
        meta.setText(n + (n == 1 ? " page" : " pages") + "  \u2022  " + StorageManager.daysLeft(s.id) + " days left");
        meta.setTextSize(12);
        meta.setTextColor(th.muted);
        info.addView(meta);

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setPadding(0, dp(8), 0, 0);
        Button view = new Button(this);
        view.setText("View");
        view.setAllCaps(false);
        view.setOnClickListener(v -> openViewer(s));
        Button del = new Button(this);
        del.setText("Delete");
        del.setAllCaps(false);
        del.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setMessage("Delete this saved work?")
                .setPositiveButton("Delete", (d, w) -> {
                    StorageManager.deleteSession(this, s.id);
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show());
        btns.addView(view);
        btns.addView(del);
        info.addView(btns);
        card.addView(info, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        list.addView(card);
    }

    private void openViewer(StorageManager.Session s) {
        Dialog dlg = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF263238);

        Button close = new Button(this);
        close.setText("Close");
        close.setAllCaps(false);
        close.setOnClickListener(v -> dlg.dismiss());
        root.addView(close);

        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(8), dp(8), dp(8));
        sv.addView(box);
        int sample = s.pages.size() > 3 ? 2 : 1;
        int idx = 1;
        ArrayList<File> files = new ArrayList<>(s.pages.values());
        for (File f : files) {
            TextView lbl = new TextView(this);
            lbl.setText("Page " + idx);
            lbl.setTextColor(Color.WHITE);
            lbl.setPadding(0, dp(8), 0, dp(4));
            box.addView(lbl);
            Bitmap b = decode(f, 100000, sample);
            if (b != null) {
                ImageView iv = new ImageView(this);
                iv.setAdjustViewBounds(true);
                iv.setImageBitmap(b);
                box.addView(iv, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            }
            idx++;
        }
        root.addView(sv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        dlg.setContentView(root);
        dlg.show();
    }

    private static Bitmap decode(File f, int reqW, int minSample) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            int sample = Math.max(1, minSample);
            while (o.outWidth / (sample * 2) >= reqW) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            return BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
        } catch (Exception e) {
            return null;
        }
    }
}
