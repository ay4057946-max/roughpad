package com.roughpad.app;

import android.content.Context;
import android.content.SharedPreferences;

/** Colour themes shared by the app screens and the floating pad. */
public class Themes {

    public static class T {
        public final String name;
        public final int primary, primaryDark, surface, chip, chipText, accent, selectMode, pageBg, card, muted;

        T(String name, int primary, int primaryDark, int surface, int chip, int chipText,
          int accent, int selectMode, int pageBg, int card, int muted) {
            this.name = name;
            this.primary = primary;
            this.primaryDark = primaryDark;
            this.surface = surface;
            this.chip = chip;
            this.chipText = chipText;
            this.accent = accent;
            this.selectMode = selectMode;
            this.pageBg = pageBg;
            this.card = card;
            this.muted = muted;
        }
    }

    public static final T[] ALL = {
            new T("Ocean", 0xFF1E88E5, 0xFF1565C0, 0xFFF5F7FA, 0xFFE3EAF2, 0xFF1F2A37, 0xFFFF9800, 0xFF2E7D32, 0xFFF0F4F8, 0xFFFFFFFF, 0xFF607D8B),
            new T("Midnight", 0xFF4F46E5, 0xFF1E1B4B, 0xFF1F2937, 0xFF374151, 0xFFE5E7EB, 0xFFFBBF24, 0xFF10B981, 0xFF0F172A, 0xFF1E293B, 0xFF94A3B8),
            new T("Forest", 0xFF2E7D32, 0xFF1B5E20, 0xFFF1F8E9, 0xFFDCEDC8, 0xFF1B3A1F, 0xFFFFB300, 0xFF1565C0, 0xFFEEF5E9, 0xFFFFFFFF, 0xFF5F7A63),
            new T("Sunset", 0xFFEF6C00, 0xFFBF360C, 0xFFFFF3E0, 0xFFFFE0B2, 0xFF4E2A06, 0xFF6A1B9A, 0xFF2E7D32, 0xFFFFF8EE, 0xFFFFFFFF, 0xFF8D6E63),
            new T("Royal", 0xFF7B1FA2, 0xFF4A148C, 0xFFF3E5F5, 0xFFE1BEE7, 0xFF2E1245, 0xFFFFC107, 0xFF2E7D32, 0xFFF8F0FA, 0xFFFFFFFF, 0xFF7E6A8A),
            new T("Rose", 0xFFD81B60, 0xFF880E4F, 0xFFFCE4EC, 0xFFF8BBD0, 0xFF4A0F25, 0xFF00897B, 0xFF1565C0, 0xFFFFF0F4, 0xFFFFFFFF, 0xFF8E6A77),
            new T("Graphite", 0xFF455A64, 0xFF263238, 0xFFECEFF1, 0xFFCFD8DC, 0xFF1C262B, 0xFFFF7043, 0xFF2E7D32, 0xFFF2F4F5, 0xFFFFFFFF, 0xFF78909C)
    };

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("roughpad_prefs", Context.MODE_PRIVATE);
    }

    public static int index(Context c) {
        int i = prefs(c).getInt("theme", 0);
        return (i < 0 || i >= ALL.length) ? 0 : i;
    }

    public static T current(Context c) {
        return ALL[index(c)];
    }

    public static void save(Context c, int i) {
        prefs(c).edit().putInt("theme", i).apply();
    }
}
