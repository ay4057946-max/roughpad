package com.roughpad.app;

import android.graphics.DashPathEffect;
import android.graphics.DiscretePathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;

import java.util.Arrays;

/** One drawn stroke (freehand, shape or pixel-eraser). Immutable once committed. */
public class Stroke {
    public static final int PEN = 0;
    public static final int PENCIL = 1;
    public static final int MARKER = 2;
    public static final int HIGHLIGHTER = 3;
    public static final int CHALK = 4;
    public static final int DOTTED = 5;
    public static final int LINE = 6;
    public static final int RECT = 7;
    public static final int OVAL = 8;
    public static final int ERASER = 9;
    public static final int STROKE_ERASER = 10; // never stored as a stroke

    public final int tool;
    public final int color;
    public final float width;
    public float[] xy = new float[64];
    public int n = 0;

    public Stroke(int tool, int color, float width) {
        this.tool = tool;
        this.color = color;
        this.width = width;
    }

    public boolean isShape() {
        return tool == LINE || tool == RECT || tool == OVAL;
    }

    public void add(float x, float y) {
        if (isShape() && n >= 2) {
            xy[2] = x;
            xy[3] = y;
            return;
        }
        if (n * 2 + 2 > xy.length) {
            xy = Arrays.copyOf(xy, xy.length * 2);
        }
        xy[n * 2] = x;
        xy[n * 2 + 1] = y;
        n++;
    }

    public Path buildPath() {
        Path p = new Path();
        if (n == 0) return p;
        float x0 = xy[0];
        float y0 = xy[1];
        if (isShape()) {
            if (n < 2) return p;
            float x1 = xy[2];
            float y1 = xy[3];
            if (tool == LINE) {
                p.moveTo(x0, y0);
                p.lineTo(x1, y1);
            } else {
                RectF r = new RectF(Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1), Math.max(y0, y1));
                if (tool == RECT) p.addRect(r, Path.Direction.CW);
                else p.addOval(r, Path.Direction.CW);
            }
            return p;
        }
        p.moveTo(x0, y0);
        if (n == 1) {
            p.lineTo(x0 + 0.1f, y0);
            return p;
        }
        if (n == 2) {
            p.lineTo(xy[2], xy[3]);
            return p;
        }
        float px = x0;
        float py = y0;
        for (int i = 1; i < n; i++) {
            float cx = xy[2 * i];
            float cy = xy[2 * i + 1];
            p.quadTo(px, py, (px + cx) / 2f, (py + cy) / 2f);
            px = cx;
            py = cy;
        }
        p.lineTo(px, py);
        return p;
    }

    public Paint makePaint() {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(color);
        float w = width;
        switch (tool) {
            case PENCIL:
                p.setStrokeWidth(Math.max(1f, w * 0.6f));
                p.setAlpha(215);
                p.setPathEffect(new DiscretePathEffect(3f, 0.9f));
                break;
            case MARKER:
                p.setStrokeWidth(w * 2f);
                p.setAlpha(235);
                break;
            case HIGHLIGHTER:
                p.setStrokeWidth(w * 4f);
                p.setAlpha(90);
                p.setStrokeCap(Paint.Cap.SQUARE);
                break;
            case CHALK:
                p.setStrokeWidth(w * 1.6f);
                p.setAlpha(200);
                p.setPathEffect(new DiscretePathEffect(w * 0.8f + 3f, w * 0.45f + 0.8f));
                break;
            case DOTTED:
                p.setStrokeWidth(w * 1.1f);
                p.setPathEffect(new DashPathEffect(new float[]{0.1f, Math.max(4f, w * 2.4f)}, 0f));
                break;
            case ERASER:
                p.setStrokeWidth(w * 3f);
                p.setColor(0xFF000000);
                p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
                break;
            default:
                p.setStrokeWidth(w);
                break;
        }
        return p;
    }

    /** Used by the "delete stroke" eraser. */
    public boolean hits(float x, float y, float r) {
        if (n == 0) return false;
        float rr = r + width / 2f;
        if (!isShape()) {
            if (n == 1) return dist(x, y, xy[0], xy[1]) <= rr;
            for (int i = 0; i < n - 1; i++) {
                if (segDist(x, y, xy[2 * i], xy[2 * i + 1], xy[2 * i + 2], xy[2 * i + 3]) <= rr) return true;
            }
            return false;
        }
        if (n < 2) return false;
        float x0 = xy[0], y0 = xy[1], x1 = xy[2], y1 = xy[3];
        if (tool == LINE) return segDist(x, y, x0, y0, x1, y1) <= rr;
        float l = Math.min(x0, x1), t = Math.min(y0, y1), rt = Math.max(x0, x1), b = Math.max(y0, y1);
        if (tool == RECT) {
            return segDist(x, y, l, t, rt, t) <= rr || segDist(x, y, rt, t, rt, b) <= rr
                    || segDist(x, y, rt, b, l, b) <= rr || segDist(x, y, l, b, l, t) <= rr;
        }
        float cx = (l + rt) / 2f, cy = (t + b) / 2f, a = (rt - l) / 2f, bb = (b - t) / 2f;
        float px = cx + a, py = cy;
        for (int i = 1; i <= 48; i++) {
            double th = i * 2 * Math.PI / 48;
            float nx = (float) (cx + a * Math.cos(th));
            float ny = (float) (cy + bb * Math.sin(th));
            if (segDist(x, y, px, py, nx, ny) <= rr) return true;
            px = nx;
            py = ny;
        }
        return false;
    }

    private static float dist(float x1, float y1, float x2, float y2) {
        float dx = x1 - x2, dy = y1 - y2;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private static float segDist(float px, float py, float ax, float ay, float bx, float by) {
        float dx = bx - ax, dy = by - ay;
        float len2 = dx * dx + dy * dy;
        if (len2 == 0f) return dist(px, py, ax, ay);
        float t = ((px - ax) * dx + (py - ay) * dy) / len2;
        t = Math.max(0f, Math.min(1f, t));
        return dist(px, py, ax + t * dx, ay + t * dy);
    }
}
