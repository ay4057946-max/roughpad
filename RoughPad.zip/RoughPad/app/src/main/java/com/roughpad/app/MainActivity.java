package com.roughpad.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private TextView status;
    private Themes.T th;

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable shape(int fill, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StorageManager.purgeOld(this);
        th = Themes.current(this);
        getWindow().setStatusBarColor(th.primaryDark);
        getWindow().setNavigationBarColor(th.pageBg);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(th.pageBg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        sv.addView(root);

        // ---- hero ----
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(22), dp(26), dp(22), dp(22));
        GradientDrawable hg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{th.primary, th.primaryDark});
        hg.setCornerRadius(dp(26));
        hero.setBackground(hg);
        TextView title = new TextView(this);
        title.setText("\u270F  Rough Pad");
        title.setTextSize(30);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.WHITE);
        hero.addView(title);
        TextView sub = new TextView(this);
        sub.setText("A floating rough page & pen for your online test. Free, no ads, works offline.");
        sub.setTextSize(14);
        sub.setTextColor(0xE6FFFFFF);
        sub.setPadding(0, dp(6), 0, dp(14));
        hero.addView(sub);
        status = new TextView(this);
        status.setTextSize(13);
        status.setTextColor(Color.WHITE);
        status.setTypeface(null, Typeface.BOLD);
        status.setPadding(dp(12), dp(6), dp(12), dp(6));
        status.setBackground(shape(0x33FFFFFF, 14, 0, 0));
        hero.addView(status, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(hero);

        // ---- actions ----
        root.addView(action("1.  Allow \"Display over other apps\"", false, v -> {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }));
        root.addView(action("2.  Start floating Rough Pad", true, v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Please allow overlay permission first", Toast.LENGTH_LONG).show();
                return;
            }
            startForegroundService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "Tap the \u270F bubble to open your rough page", Toast.LENGTH_LONG).show();
            moveTaskToBack(true);
        }));
        root.addView(action("Stop Rough Pad", false, v ->
                startService(new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_STOP))));
        root.addView(action("Saved rough work  (kept 90 days)", false, v ->
                startActivity(new Intent(this, HistoryActivity.class))));

        // ---- theme picker ----
        LinearLayout themeCard = card();
        TextView tl = new TextView(this);
        tl.setText("Colour theme  \u2022  " + th.name);
        tl.setTextSize(15);
        tl.setTypeface(null, Typeface.BOLD);
        tl.setTextColor(th.chipText);
        themeCard.addView(tl);
        LinearLayout dots = new LinearLayout(this);
        dots.setOrientation(LinearLayout.HORIZONTAL);
        dots.setPadding(0, dp(12), 0, 0);
        for (int i = 0; i < Themes.ALL.length; i++) {
            final int idx = i;
            View d = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(Themes.ALL[i].primary);
            boolean sel = i == Themes.index(this);
            g.setStroke(sel ? dp(4) : dp(1), sel ? th.chipText : 0x33000000);
            d.setBackground(g);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
            lp.setMargins(0, 0, dp(10), 0);
            d.setLayoutParams(lp);
            d.setOnClickListener(v -> {
                Themes.save(this, idx);
                recreate();
            });
            dots.addView(d);
        }
        themeCard.addView(dots);
        TextView note = new TextView(this);
        note.setText("Also change it any time with the Theme button inside the pad.");
        note.setTextSize(12);
        note.setTextColor(th.muted);
        note.setPadding(0, dp(10), 0, 0);
        themeCard.addView(note);
        root.addView(themeCard);

        // ---- help ----
        LinearLayout helpCard = card();
        TextView ht = new TextView(this);
        ht.setText("How to use");
        ht.setTextSize(15);
        ht.setTypeface(null, Typeface.BOLD);
        ht.setTextColor(th.chipText);
        helpCard.addView(ht);
        TextView help = new TextView(this);
        help.setText("\u2022 Start Rough Pad, then open your test. A \u270F bubble floats on screen.\n"
                + "\u2022 Tap the bubble to open the pad. Drag the top bar to move it.\n"
                + "\u2022 Resize (top bar) shows 8 handles: drag any corner or edge. Tap anywhere else to finish.\n"
                + "\u2022 Tools: pen, pencil, marker, highlighter, chalk, dotted, line, box, oval, eraser, delete-stroke.\n"
                + "\u2022 Two fingers: drag to scroll the page, pinch to zoom. Home = back to start.\n"
                + "\u2022 Select = the pad turns into a see-through overlay and touches go to your test. Tap the \u270F bubble to draw again.\n"
                + "\u2022 Undo / Redo, Clear (long-press = all pages), pages, paper styles, Bg % see-through, Theme colours.\n"
                + "\u2022 Hide = back to bubble. Exit = stop and save to history.\n"
                + "\u2022 Work is auto-saved and deleted automatically after 90 days.\n\n"
                + "Some secure exam apps block floating windows. It works with normal browsers and most test apps.");
        help.setTextSize(13);
        help.setLineSpacing(dp(2), 1f);
        help.setTextColor(th.muted);
        help.setPadding(0, dp(8), 0, 0);
        helpCard.addView(help);
        root.addView(helpCard);

        setContentView(sv);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(16), dp(18), dp(16));
        c.setBackground(shape(th.card, 20, 0, 0));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(14), 0, 0);
        c.setLayoutParams(lp);
        return c;
    }

    private TextView action(String text, boolean filled, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextSize(16);
        b.setTypeface(null, Typeface.BOLD);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(16), dp(15), dp(16), dp(15));
        if (filled) {
            b.setTextColor(Color.WHITE);
            b.setBackground(shape(th.primary, 28, 0, 0));
        } else {
            b.setTextColor(th.primary);
            b.setBackground(shape(th.card, 28, th.primary, 2));
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(14), 0, 0);
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Settings.canDrawOverlays(this)) {
            status.setText("\u2714  Overlay permission granted");
        } else {
            status.setText("\u2718  Overlay permission needed (step 1)");
        }
    }
}
