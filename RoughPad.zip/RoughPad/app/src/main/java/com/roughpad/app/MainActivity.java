package com.roughpad.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private TextView status;

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StorageManager.purgeOld(this);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.WHITE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(36), dp(20), dp(24));
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("Rough Pad");
        title.setTextSize(30);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(0xFF1E88E5);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("A floating rough page & pen that stays on top of your online test. Free, no ads, no internet needed.");
        sub.setTextSize(14);
        sub.setTextColor(0xFF455A64);
        sub.setPadding(0, dp(6), 0, dp(16));
        root.addView(sub);

        status = new TextView(this);
        status.setTextSize(14);
        status.setPadding(0, 0, 0, dp(8));
        root.addView(status);

        root.addView(button("1. Allow \"Display over other apps\"", v -> {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }));

        root.addView(button("2. Start floating Rough Pad", v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Please allow overlay permission first", Toast.LENGTH_LONG).show();
                return;
            }
            startForegroundService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "Tap the \u270F bubble to open your rough page", Toast.LENGTH_LONG).show();
            moveTaskToBack(true);
        }));

        root.addView(button("Stop Rough Pad", v ->
                startService(new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_STOP))));

        root.addView(button("Saved rough work (kept 90 days)", v ->
                startActivity(new Intent(this, HistoryActivity.class))));

        TextView help = new TextView(this);
        help.setText("How to use\n"
                + "\u2022 Start Rough Pad, then open your test. A \u270F bubble floats on screen.\n"
                + "\u2022 Tap the bubble to open the rough page. Drag the blue bar to move it, drag the \u25E2 corner to resize.\n"
                + "\u2022 Tools: pen, pencil, marker, highlighter, chalk, dotted, line, box, oval, eraser, delete-stroke.\n"
                + "\u2022 Undo / Redo, Clear (long-press = clear all pages), multiple pages, paper styles, background see-through (Bg %).\n"
                + "\u2022 Resize (blue bar) shows 8 orange handles: drag any corner or edge to resize in that direction, then tap Done.\n"
                + "\u2022 Two fingers: drag to scroll the page in any direction, pinch to zoom. Home = back to start.\n"
                + "\u2022 Select = pad becomes a see-through overlay and your touches go to the test (tick answers, scroll). Tap the green \u270F bubble to draw again.\n"
                + "\u2022 Hide = back to bubble. Exit = stop and save to history.\n"
                + "\u2022 Work is auto-saved. History is deleted automatically after 90 days.\n\n"
                + "Note: some secure exam apps block floating windows. It works with normal browsers and most test apps.");
        help.setTextSize(13);
        help.setTextColor(0xFF37474F);
        help.setPadding(0, dp(20), 0, 0);
        root.addView(help);

        setContentView(sv);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(6), 0, dp(6));
        b.setLayoutParams(lp);
        b.setGravity(Gravity.CENTER);
        return b;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Settings.canDrawOverlays(this)) {
            status.setText("\u2714 Overlay permission granted");
            status.setTextColor(0xFF2E7D32);
        } else {
            status.setText("\u2718 Overlay permission needed (step 1)");
            status.setTextColor(0xFFC62828);
        }
    }
}
