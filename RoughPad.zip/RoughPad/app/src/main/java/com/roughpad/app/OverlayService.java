package com.roughpad.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Outline;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.WindowMetrics;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/** Foreground service that shows a floating bubble + floating rough-work panel. */
public class OverlayService extends Service {

    public static final String ACTION_STOP = "com.roughpad.app.STOP";
    public static final String ACTION_SHOW = "com.roughpad.app.SHOW";
    private static final String CHANNEL_ID = "roughpad_channel";

    private static final int[] COLORS = {
            0xFF000000, 0xFF1565C0, 0xFFD32F2F, 0xFF2E7D32, 0xFFEF6C00,
            0xFF6A1B9A, 0xFF5D4037, 0xFF607D8B, 0xFF00ACC1, 0xFFFFFFFF
    };
    private static final String[] TOOL_NAMES = {
            "Pen", "Pencil", "Marker", "Hilite", "Chalk", "Dots", "Line", "Box", "Oval", "Eraser", "Del Stroke"
    };
    private static final int[] ALPHAS = {255, 180, 110, 50};

    private WindowManager wm;
    private TextView bubble;
    private WindowManager.LayoutParams bubbleLp;
    private boolean bubbleAttached = false;
    private FrameLayout panel;
    private LinearLayout content;
    private FrameLayout resizeLayer;
    private TextView resizeBtn;
    private boolean resizeMode = false;
    private float uiScale = 1f;
    private final ArrayList<View> scViews = new ArrayList<>();
    private final ArrayList<float[]> scBase = new ArrayList<>();
    private WindowManager.LayoutParams panelLp;
    private boolean panelAttached = false;
    private DrawingView drawing;
    private TextView pageLabel, paperBtn, alphaBtn, fullBtn;
    private LinearLayout toolsBox;
    private final ArrayList<TextView> toolBtns = new ArrayList<>();
    private final ArrayList<View> swatches = new ArrayList<>();
    private int selColorIdx = 0;
    private int alphaIdx = 0;
    private boolean fullscreen = false;
    private boolean dirty = false;
    private int savedX, savedY, savedW, savedH;
    private int areaL, areaT, areaR, areaB; // safe usable screen area (below status bar etc.)
    private int prefW, prefH;
    private static final int HIDDEN = 0, DRAW = 1, SELECT = 2;
    private int mode = HIDDEN;
    private LinearLayout header;
    private TextView handle;
    private GradientDrawable border;
    private boolean toolsOpen = true;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable autosave = new Runnable() {
        @Override
        public void run() {
            saveCurrent();
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopEverything();
            return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Please allow 'Display over other apps' first");
            stopSelf();
            return START_NOT_STICKY;
        }
        startFg();
        if (panel == null) buildUi();
        if (ACTION_SHOW.equals(action)) setMode(DRAW);
        else if (!panelAttached && !bubbleAttached) setMode(HIDDEN);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(autosave);
        removeViews();
        super.onDestroy();
    }

    // ---------- foreground notification ----------

    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "Rough Pad", NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent sp = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent show = new Intent(this, OverlayService.class).setAction(ACTION_SHOW);
        PendingIntent shp = PendingIntent.getService(this, 2, show, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Rough Pad is running")
                .setContentText("Tap to open your rough page")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentIntent(shp)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", sp)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    // ---------- helpers ----------

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private GradientDrawable rounded(int color, int radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    private WindowManager.LayoutParams newLp(int w, int h) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        return lp;
    }

    private TextView btn(String label, View.OnClickListener l) {
        return btn(label, l, 12f, 10, 6);
    }

    private TextView btn(String label, View.OnClickListener l, float sp, int padH, int padV) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(sp * uiScale);
        t.setTextColor(0xFF263238);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(padH * uiScale), dp(padV * uiScale), dp(padH * uiScale), dp(padV * uiScale));
        t.setBackground(rounded(0xFFECEFF1, dp(8)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        t.setLayoutParams(lp);
        t.setOnClickListener(l);
        scalable(t, sp, padH, padV);
        return t;
    }

    private TextView headerBtn(String label, View.OnClickListener l) {
        TextView t = btn(label, l, 11f, 7, 4);
        t.setTextColor(Color.WHITE);
        t.setBackground(rounded(0x33FFFFFF, dp(8)));
        return t;
    }

    /** Registers a text view so its size/padding follow the panel size (responsive toolbars). */
    private void scalable(TextView t, float sp, int padH, int padV) {
        scViews.add(t);
        scBase.add(new float[]{sp, padH, padV});
    }

    private float computeScale() {
        float ws = panelLp.width / (float) dp(380);
        float hs = panelLp.height / (float) dp(420);
        return Math.max(0.72f, Math.min(1.35f, Math.min(ws, hs)));
    }

    private void maybeRescale() {
        if (panelLp == null || content == null) return;
        float ns = computeScale();
        if (Math.abs(ns - uiScale) > 0.04f) {
            uiScale = ns;
            applyUiScale();
        }
    }

    private void applyUiScale() {
        for (int i = 0; i < scViews.size(); i++) {
            View v = scViews.get(i);
            float[] b = scBase.get(i);
            if (v instanceof TextView) {
                TextView tv = (TextView) v;
                tv.setTextSize(b[0] * uiScale);
                if (b[1] >= 0) {
                    tv.setPadding(dp(b[1] * uiScale), dp(b[2] * uiScale), dp(b[1] * uiScale), dp(b[2] * uiScale));
                }
            }
        }
        for (View sw : swatches) {
            ViewGroup.LayoutParams lp = sw.getLayoutParams();
            lp.width = dp(28 * uiScale);
            lp.height = dp(28 * uiScale);
            sw.setLayoutParams(lp);
        }
    }

    private LinearLayout newRow(LinearLayout parent) {
        HorizontalScrollView sv = new HorizontalScrollView(this);
        sv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), dp(2), dp(4), dp(2));
        sv.addView(row);
        parent.addView(sv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return row;
    }

    // ---------- UI construction ----------

    private void buildUi() {
        computeArea();
        buildBubble();
        buildPanel();
        StorageManager.purgeOld(this);
        String saved = StorageManager.loadCurrent(this);
        if (saved != null && drawing.loadJson(saved)) {
            dirty = drawing.hasContent();
        }
    }

    private void buildBubble() {
        bubble = new TextView(this);
        bubble.setText("\u270F");
        bubble.setTextSize(24);
        bubble.setGravity(Gravity.CENTER);
        bubble.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0xEE1E88E5);
        g.setStroke(dp(2), Color.WHITE);
        bubble.setBackground(g);
        bubbleLp = newLp(dp(54), dp(54));
        bubbleLp.x = areaR - dp(70);
        bubbleLp.y = areaT + ah() / 3;
        bubble.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = bubbleLp.x;
                        sy = bubbleLp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - tx;
                        float dy = e.getRawY() - ty;
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                        if (moved) {
                            bubbleLp.x = clamp(sx + (int) dx, areaL, Math.max(areaL, areaR - dp(54)));
                            bubbleLp.y = clamp(sy + (int) dy, areaT, Math.max(areaT, areaB - dp(54)));
                            if (bubbleAttached) wm.updateViewLayout(bubble, bubbleLp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) setMode(DRAW);
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void buildPanel() {
        panel = new FrameLayout(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        panel.addView(content, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        // curved corners + border drawn on top of the content
        final float radius = dp(14);
        border = new GradientDrawable();
        border.setColor(Color.TRANSPARENT);
        border.setCornerRadius(radius);
        border.setStroke(dp(3), 0xFF1E88E5);
        panel.setForeground(border);
        panel.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
            }
        });
        panel.setClipToOutline(true);

        int pw = Math.min((int) (aw() * 0.94f), dp(560));
        int ph = Math.max(dp(240), Math.min(ah(), (int) (ah() * 0.6f)));
        prefW = pw;
        prefH = ph;
        panelLp = newLp(pw, ph);
        panelLp.x = areaL + (aw() - pw) / 2;
        panelLp.y = clamp(areaT + (int) (ah() * 0.06f), areaT, Math.max(areaT, areaB - ph));
        uiScale = computeScale();

        drawing = new DrawingView(this);

        // ---- header (drag handle) ----
        header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(0xFF1E88E5);
        header.setPadding(dp(8), dp(4), dp(4), dp(4));

        TextView title = new TextView(this);
        title.setText("Rough");
        title.setTextColor(Color.WHITE);
        title.setTextSize(14);
        title.setTypeface(null, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        scalable(title, 14f, -1, -1);

        pageLabel = new TextView(this);
        pageLabel.setText("1/1");
        pageLabel.setTextColor(Color.WHITE);
        pageLabel.setTextSize(12);
        pageLabel.setPadding(dp(6), 0, dp(6), 0);
        header.addView(pageLabel);
        scalable(pageLabel, 12f, -1, -1);

        header.addView(headerBtn("Tools", v -> {
            toolsOpen = !toolsOpen;
            toolsBox.setVisibility(toolsOpen ? View.VISIBLE : View.GONE);
        }));
        resizeBtn = headerBtn("Resize", v -> setResizeMode(!resizeMode));
        header.addView(resizeBtn);
        header.addView(headerBtn("Select", v -> {
            setMode(SELECT);
            toast("Select mode: touches go to your test. Tap the \u270F bubble to draw again.");
        }));
        header.addView(headerBtn("Hide", v -> hidePanel()));
        header.addView(headerBtn("Exit", v -> stopEverything()));

        header.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (fullscreen) return true;
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = panelLp.x;
                        sy = panelLp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.x = clamp(sx + (int) (e.getRawX() - tx), areaL - panelLp.width + dp(90), areaR - dp(90));
                        panelLp.y = clamp(sy + (int) (e.getRawY() - ty), areaT, Math.max(areaT, areaB - dp(60)));
                        updatePanel();
                        return true;
                    default:
                        return true;
                }
            }
        });
        content.addView(header, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // ---- tools box ----
        toolsBox = new LinearLayout(this);
        toolsBox.setOrientation(LinearLayout.VERTICAL);
        toolsBox.setBackgroundColor(0xFFF5F7FA);

        // row A: tools
        LinearLayout rowA = newRow(toolsBox);
        for (int i = 0; i < TOOL_NAMES.length; i++) {
            final int t = i;
            TextView b = btn(TOOL_NAMES[i], v -> selectTool(t));
            toolBtns.add(b);
            rowA.addView(b);
        }

        // row B: colours
        LinearLayout rowB = newRow(toolsBox);
        for (int i = 0; i < COLORS.length; i++) {
            final int idx = i;
            View sw = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(28), dp(28));
            lp.setMargins(dp(4), dp(2), dp(4), dp(2));
            sw.setLayoutParams(lp);
            sw.setOnClickListener(v -> selectColor(idx));
            swatches.add(sw);
            rowB.addView(sw);
        }

        // row C: size + paper + background transparency
        LinearLayout rowC = new LinearLayout(this);
        rowC.setOrientation(LinearLayout.HORIZONTAL);
        rowC.setGravity(Gravity.CENTER_VERTICAL);
        rowC.setPadding(dp(8), 0, dp(4), 0);
        TextView sizeLbl = new TextView(this);
        sizeLbl.setText("Size");
        sizeLbl.setTextSize(12);
        sizeLbl.setTextColor(0xFF263238);
        rowC.addView(sizeLbl);
        scalable(sizeLbl, 12f, -1, -1);
        SeekBar sb = new SeekBar(this);
        sb.setMax(30);
        sb.setProgress(5);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                drawing.setBrushLevel(p + 1);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        rowC.addView(sb, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        paperBtn = btn("Plain", v -> paperBtn.setText(drawing.cyclePaper()));
        rowC.addView(paperBtn);
        alphaBtn = btn("Bg 100%", v -> {
            alphaIdx = (alphaIdx + 1) % ALPHAS.length;
            drawing.setPaperAlpha(ALPHAS[alphaIdx]);
            alphaBtn.setText("Bg " + (ALPHAS[alphaIdx] * 100 / 255) + "%");
        });
        rowC.addView(alphaBtn);
        toolsBox.addView(rowC, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // row D: actions
        LinearLayout rowD = newRow(toolsBox);
        rowD.addView(btn("Undo", v -> drawing.undo()));
        rowD.addView(btn("Redo", v -> drawing.redo()));
        TextView clearBtn = btn("Clear", v -> drawing.clearPage());
        clearBtn.setOnLongClickListener(v -> {
            archiveSession(false, false);
            drawing.reset();
            toast("All pages cleared (old work saved in history)");
            return true;
        });
        rowD.addView(clearBtn);
        rowD.addView(btn("+Page", v -> drawing.newPage()));
        rowD.addView(btn("Home", v -> drawing.resetView()));
        fullBtn = btn("Full", v -> toggleFullscreen());
        rowD.addView(fullBtn);
        rowD.addView(btn("Prev", v -> drawing.prevPage()));
        rowD.addView(btn("Next", v -> drawing.nextPage()));
        rowD.addView(btn("Save", v -> archiveSession(false, true)));

        content.addView(toolsBox, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // ---- canvas + resize handle ----
        FrameLayout canvasBox = new FrameLayout(this);
        canvasBox.addView(drawing, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        handle = new TextView(this);
        handle.setText("\u25E2");
        handle.setTextSize(18);
        handle.setTextColor(0xFF1E88E5);
        handle.setGravity(Gravity.CENTER);
        handle.setBackground(rounded(0x99FFFFFF, dp(6)));
        handle.setOnTouchListener(new View.OnTouchListener() {
            int w0, h0;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (fullscreen) return true;
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        w0 = panelLp.width;
                        h0 = panelLp.height;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.width = clamp(w0 + (int) (e.getRawX() - tx), Math.min(dp(240), aw()),
                                Math.max(dp(240), Math.min(aw(), areaR - panelLp.x)));
                        panelLp.height = clamp(h0 + (int) (e.getRawY() - ty), Math.min(dp(220), ah()),
                                Math.max(dp(220), Math.min(ah(), areaB - panelLp.y)));
                        prefW = panelLp.width;
                        prefH = panelLp.height;
                        updatePanel();
                        return true;
                    default:
                        return true;
                }
            }
        });
        canvasBox.addView(handle, new FrameLayout.LayoutParams(dp(36), dp(36), Gravity.BOTTOM | Gravity.END));
        content.addView(canvasBox, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        buildResizeLayer();
        panel.addView(resizeLayer, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        selectTool(Stroke.PEN);
        refreshSwatches();
        applyUiScale();

        drawing.setListener(new DrawingView.Listener() {
            @Override
            public void onChanged() {
                dirty = true;
                handler.removeCallbacks(autosave);
                handler.postDelayed(autosave, 1500);
            }

            @Override
            public void onPageChanged(int index, int count) {
                pageLabel.setText((index + 1) + "/" + count);
                paperBtn.setText(drawing.paperName());
            }
        });
    }

    // ---------- 8-direction resize ----------

    private void applyBorder() {
        int c;
        if (mode == SELECT) c = Color.TRANSPARENT;
        else if (resizeMode) c = 0xFFFF9800;
        else c = 0xFF1E88E5;
        border.setStroke(resizeMode && mode != SELECT ? dp(4) : dp(3), c);
        panel.invalidate();
    }

    private void setResizeMode(boolean on) {
        if (resizeLayer == null) return;
        if (on && fullscreen) toggleFullscreen();
        resizeMode = on;
        resizeLayer.setVisibility(on ? View.VISIBLE : View.GONE);
        resizeBtn.setText(on ? "Done" : "Resize");
        resizeBtn.setBackground(rounded(on ? 0xFFFF9800 : 0x33FFFFFF, dp(8)));
        if (handle != null && mode != SELECT) handle.setVisibility(on ? View.GONE : View.VISIBLE);
        applyBorder();
    }

    private void buildResizeLayer() {
        resizeLayer = new FrameLayout(this);
        resizeLayer.setVisibility(View.GONE);
        addResizeHandle(Gravity.TOP | Gravity.START, -1, -1, 0, "\u2196");
        addResizeHandle(Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, -1, 1, "\u2191");
        addResizeHandle(Gravity.TOP | Gravity.END, 1, -1, 0, "\u2197");
        addResizeHandle(Gravity.CENTER_VERTICAL | Gravity.START, -1, 0, 2, "\u2190");
        addResizeHandle(Gravity.CENTER_VERTICAL | Gravity.END, 1, 0, 2, "\u2192");
        addResizeHandle(Gravity.BOTTOM | Gravity.START, -1, 1, 0, "\u2199");
        addResizeHandle(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 1, 1, "\u2193");
        addResizeHandle(Gravity.BOTTOM | Gravity.END, 1, 1, 0, "\u2198");
    }

    /** kind: 0 = corner, 1 = horizontal edge, 2 = vertical edge. dx/dy = direction the handle pulls. */
    private void addResizeHandle(int gravity, final int dirX, final int dirY, int kind, String arrow) {
        TextView h = new TextView(this);
        h.setText(arrow);
        h.setTextColor(Color.WHITE);
        h.setTextSize(16);
        h.setTypeface(null, Typeface.BOLD);
        h.setGravity(Gravity.CENTER);
        int wDp = kind == 1 ? 72 : (kind == 2 ? 26 : 36);
        int hDp = kind == 1 ? 26 : (kind == 2 ? 72 : 36);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xF2FF9800);
        g.setStroke(dp(2), Color.WHITE);
        g.setCornerRadius(dp(14));
        h.setBackground(g);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(wDp), dp(hDp), gravity);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        h.setOnTouchListener(new View.OnTouchListener() {
            int x0, y0, w0, h0;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (fullscreen) return true;
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        x0 = panelLp.x;
                        y0 = panelLp.y;
                        w0 = panelLp.width;
                        h0 = panelLp.height;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    }
                    case MotionEvent.ACTION_MOVE: {
                        int mx = (int) (e.getRawX() - tx);
                        int my = (int) (e.getRawY() - ty);
                        int minW = Math.min(dp(240), aw());
                        int minH = Math.min(dp(200), ah());
                        if (dirX > 0) {
                            panelLp.width = clamp(w0 + mx, minW, Math.max(minW, areaR - x0));
                            panelLp.x = x0;
                        } else if (dirX < 0) {
                            int nw = clamp(w0 - mx, minW, Math.max(minW, x0 + w0 - areaL));
                            panelLp.width = nw;
                            panelLp.x = x0 + w0 - nw;
                        }
                        if (dirY > 0) {
                            panelLp.height = clamp(h0 + my, minH, Math.max(minH, areaB - y0));
                            panelLp.y = y0;
                        } else if (dirY < 0) {
                            int nh = clamp(h0 - my, minH, Math.max(minH, y0 + h0 - areaT));
                            panelLp.height = nh;
                            panelLp.y = y0 + h0 - nh;
                        }
                        prefW = panelLp.width;
                        prefH = panelLp.height;
                        updatePanel();
                        return true;
                    }
                    default:
                        return true;
                }
            }
        });
        resizeLayer.addView(h, lp);
    }

    // ---------- tool / colour selection ----------

    private void selectTool(int t) {
        drawing.setTool(t);
        for (int i = 0; i < toolBtns.size(); i++) {
            toolBtns.get(i).setBackground(rounded(i == t ? 0xFF90CAF9 : 0xFFECEFF1, dp(8)));
        }
    }

    private void selectColor(int idx) {
        selColorIdx = idx;
        drawing.setColor(COLORS[idx]);
        if (drawing.getTool() >= Stroke.ERASER) selectTool(Stroke.PEN);
        refreshSwatches();
    }

    private void refreshSwatches() {
        for (int i = 0; i < swatches.size(); i++) {
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(COLORS[i]);
            boolean sel = i == selColorIdx;
            g.setStroke(sel ? dp(3) : dp(1), sel ? 0xFF1E88E5 : 0xFF90A4AE);
            swatches.get(i).setBackground(g);
        }
    }

    // ---------- window management ----------

    private void updatePanel() {
        maybeRescale();
        if (panelAttached) {
            try {
                wm.updateViewLayout(panel, panelLp);
            } catch (Exception ignored) {
            }
        }
    }

    private void toggleFullscreen() {
        if (!fullscreen) {
            savedX = panelLp.x;
            savedY = panelLp.y;
            savedW = panelLp.width;
            savedH = panelLp.height;
            panelLp.x = areaL;
            panelLp.y = areaT;
            panelLp.width = aw();
            panelLp.height = ah();
            fullscreen = true;
            fullBtn.setText("Restore");
        } else {
            panelLp.width = Math.min(savedW, aw());
            panelLp.height = Math.min(savedH, ah());
            panelLp.x = clamp(savedX, areaL, Math.max(areaL, areaR - panelLp.width));
            panelLp.y = clamp(savedY, areaT, Math.max(areaT, areaB - panelLp.height));
            fullscreen = false;
            fullBtn.setText("Full");
        }
        updatePanel();
    }

    private void attachBubble() {
        if (!bubbleAttached) {
            try {
                wm.addView(bubble, bubbleLp);
                bubbleAttached = true;
            } catch (Exception ignored) {
            }
        }
    }

    private void detachBubble() {
        if (bubbleAttached) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubbleAttached = false;
        }
    }

    private void attachPanel() {
        if (!panelAttached) {
            try {
                wm.addView(panel, panelLp);
                panelAttached = true;
            } catch (Exception ignored) {
            }
        }
    }

    private void detachPanel() {
        if (panelAttached) {
            try {
                wm.removeView(panel);
            } catch (Exception ignored) {
            }
            panelAttached = false;
        }
    }

    /** HIDDEN = bubble only, DRAW = pad active with tools, SELECT = pad is a see-through overlay, touches pass through. */
    private void setMode(int m) {
        if (m != DRAW) saveCurrent();
        mode = m;
        if (m != DRAW) setResizeMode(false);
        if (m == DRAW) {
            attachPanel();
            setPassThrough(false);
            detachBubble();
        } else if (m == SELECT) {
            attachPanel();
            setPassThrough(true);
            attachBubble();
        } else {
            detachPanel();
            attachBubble();
        }
        updateBubbleStyle();
    }

    private void updateBubbleStyle() {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(mode == SELECT ? 0xEE2E7D32 : 0xEE1E88E5);
        g.setStroke(dp(2), Color.WHITE);
        bubble.setBackground(g);
    }

    private void setPassThrough(boolean on) {
        header.setVisibility(on ? View.INVISIBLE : View.VISIBLE);
        if (on) setResizeMode(false);
        handle.setVisibility(on ? View.INVISIBLE : (resizeMode ? View.GONE : View.VISIBLE));
        if (on) toolsBox.setVisibility(toolsOpen ? View.INVISIBLE : View.GONE);
        else toolsBox.setVisibility(toolsOpen ? View.VISIBLE : View.GONE);
        applyBorder();
        if (on) {
            panelLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            panelLp.alpha = 0.78f; // Android 12+ only lets touches through windows with alpha <= 0.8
        } else {
            panelLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            panelLp.alpha = 1f;
        }
        updatePanel();
    }

    private void hidePanel() {
        setMode(HIDDEN);
    }

    // ---------- safe area + rotation ----------

    private int aw() {
        return Math.max(1, areaR - areaL);
    }

    private int ah() {
        return Math.max(1, areaB - areaT);
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : 0;
    }

    @android.annotation.TargetApi(30)
    private void computeAreaApi30() {
        WindowMetrics m = wm.getCurrentWindowMetrics();
        Rect bounds = m.getBounds();
        Insets ins = m.getWindowInsets().getInsetsIgnoringVisibility(
                WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
        areaL = ins.left;
        areaT = ins.top;
        areaR = bounds.width() - ins.right;
        areaB = bounds.height() - ins.bottom;
    }

    private void computeArea() {
        if (Build.VERSION.SDK_INT >= 30) {
            computeAreaApi30();
        } else {
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getMetrics(dm);
            areaL = 0;
            areaT = 0;
            areaR = dm.widthPixels;
            areaB = dm.heightPixels;
        }
        areaT = Math.max(areaT, statusBarHeight());
        if (areaR - areaL < dp(200) || areaB - areaT < dp(200)) {
            DisplayMetrics dm2 = getResources().getDisplayMetrics();
            areaL = 0;
            areaT = statusBarHeight();
            areaR = dm2.widthPixels;
            areaB = dm2.heightPixels;
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        relayout();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                relayout();
            }
        }, 350);
    }

    private void relayout() {
        if (panel == null || bubble == null) return;
        int oL = areaL;
        int oT = areaT;
        int oW = aw();
        int oH = ah();
        computeArea();
        int nW = aw();
        int nH = ah();

        bubbleLp.x = clamp(areaL + Math.round((bubbleLp.x - oL) * (float) nW / oW), areaL, Math.max(areaL, areaR - dp(54)));
        bubbleLp.y = clamp(areaT + Math.round((bubbleLp.y - oT) * (float) nH / oH), areaT, Math.max(areaT, areaB - dp(54)));
        if (bubbleAttached) {
            try {
                wm.updateViewLayout(bubble, bubbleLp);
            } catch (Exception ignored) {
            }
        }

        if (fullscreen) {
            panelLp.x = areaL;
            panelLp.y = areaT;
            panelLp.width = nW;
            panelLp.height = nH;
        } else {
            panelLp.width = Math.min(prefW, nW);
            panelLp.height = Math.min(prefH, nH);
            int nx = areaL + Math.round((panelLp.x - oL) * (float) nW / oW);
            int ny = areaT + Math.round((panelLp.y - oT) * (float) nH / oH);
            panelLp.x = clamp(nx, areaL, Math.max(areaL, areaR - panelLp.width));
            panelLp.y = clamp(ny, areaT, Math.max(areaT, areaB - panelLp.height));
        }
        updatePanel();
    }

    private void removeViews() {
        if (panelAttached) {
            try {
                wm.removeView(panel);
            } catch (Exception ignored) {
            }
            panelAttached = false;
        }
        if (bubbleAttached) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubbleAttached = false;
        }
    }

    // ---------- saving ----------

    private void saveCurrent() {
        if (drawing == null) return;
        try {
            if (drawing.hasContent()) StorageManager.saveCurrent(this, drawing.toJson().toString());
            else StorageManager.clearCurrent(this);
        } catch (Exception ignored) {
        }
    }

    private void archiveSession(boolean sync, final boolean showToast) {
        if (drawing == null || !drawing.hasContent()) {
            if (showToast) toast("Nothing to save yet");
            return;
        }
        final String json;
        try {
            json = drawing.toJson().toString();
        } catch (Exception e) {
            return;
        }
        final ArrayList<Bitmap> bmps = drawing.renderAllPages();
        dirty = false;
        Runnable job = new Runnable() {
            @Override
            public void run() {
                StorageManager.saveSession(OverlayService.this, json, bmps);
                for (Bitmap b : bmps) b.recycle();
                if (showToast) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            toast("Saved to history (kept for 90 days)");
                        }
                    });
                }
            }
        };
        if (sync) job.run();
        else new Thread(job).start();
    }

    private void stopEverything() {
        handler.removeCallbacks(autosave);
        if (drawing != null && dirty && drawing.hasContent()) {
            archiveSession(true, false);
        }
        StorageManager.clearCurrent(this);
        removeViews();
        stopForeground(Service.STOP_FOREGROUND_REMOVE);
        stopSelf();
    }
}
