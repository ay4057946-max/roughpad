package com.roughpad.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/** Foreground service that shows a floating bubble + floating rough-work panel. */
public class OverlayService extends Service {

    public static final String ACTION_STOP = "com.roughpad.app.STOP";
    public static final String ACTION_SHOW = "com.roughpad.app.SHOW";
    private static final String CHANNEL_ID = "roughpad_channel";

    private static final int[] COLORS = {
            0xFF000000, 0xFF1565C0, 0xFFD32F2F, 0xFF2E7D32, 0xFFEF6C00,
            0xFF6A1B9A, 0xFF5D4037, 0xFF607D8B, 0xFF00ACC1, 0xFFFFFFFF
    };
    private static final String[] TOOL_NAMES = {
            "Pen", "Pencil", "Marker", "Hilite", "Chalk", "Dots", "Line", "Box", "Oval", "Eraser", "Del Stroke"
    };
    private static final int[] ALPHAS = {255, 180, 110, 50};

    private WindowManager wm;
    private TextView bubble;
    private WindowManager.LayoutParams bubbleLp;
    private boolean bubbleAttached = false;
    private LinearLayout panel;
    private WindowManager.LayoutParams panelLp;
    private boolean panelAttached = false;
    private DrawingView drawing;
    private TextView pageLabel, paperBtn, alphaBtn, fullBtn;
    private LinearLayout toolsBox;
    private final ArrayList<TextView> toolBtns = new ArrayList<>();
    private final ArrayList<View> swatches = new ArrayList<>();
    private int selColorIdx = 0;
    private int alphaIdx = 0;
    private boolean fullscreen = false;
    private boolean dirty = false;
    private int savedX, savedY, savedW, savedH;
    private int screenW, screenH;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable autosave = new Runnable() {
        @Override
        public void run() {
            saveCurrent();
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopEverything();
            return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Please allow 'Display over other apps' first");
            stopSelf();
            return START_NOT_STICKY;
        }
        startFg();
        if (panel == null) buildUi();
        if (ACTION_SHOW.equals(action)) showPanel();
        else if (!panelAttached && !bubbleAttached) showBubble();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(autosave);
        removeViews();
        super.onDestroy();
    }

    // ---------- foreground notification ----------

    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "Rough Pad", NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent sp = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent show = new Intent(this, OverlayService.class).setAction(ACTION_SHOW);
        PendingIntent shp = PendingIntent.getService(this, 2, show, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Rough Pad is running")
                .setContentText("Tap to open your rough page")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentIntent(shp)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", sp)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    // ---------- helpers ----------

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private GradientDrawable rounded(int color, int radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    private WindowManager.LayoutParams newLp(int w, int h) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        return lp;
    }

    private TextView btn(String label, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(12);
        t.setTextColor(0xFF263238);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(6), dp(10), dp(6));
        t.setBackground(rounded(0xFFECEFF1, dp(8)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        t.setLayoutParams(lp);
        t.setOnClickListener(l);
        return t;
    }

    private TextView headerBtn(String label, View.OnClickListener l) {
        TextView t = btn(label, l);
        t.setTextColor(Color.WHITE);
        t.setBackground(rounded(0x33FFFFFF, dp(8)));
        t.setPadding(dp(8), dp(4), dp(8), dp(4));
        return t;
    }

    private LinearLayout newRow(LinearLayout parent) {
        HorizontalScrollView sv = new HorizontalScrollView(this);
        sv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), dp(2), dp(4), dp(2));
        sv.addView(row);
        parent.addView(sv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return row;
    }

    // ---------- UI construction ----------

    private void buildUi() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        buildBubble();
        buildPanel();
        StorageManager.purgeOld(this);
        String saved = StorageManager.loadCurrent(this);
        if (saved != null && drawing.loadJson(saved)) {
            dirty = drawing.hasContent();
        }
    }

    private void buildBubble() {
        bubble = new TextView(this);
        bubble.setText("\u270F");
        bubble.setTextSize(24);
        bubble.setGravity(Gravity.CENTER);
        bubble.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0xEE1E88E5);
        g.setStroke(dp(2), Color.WHITE);
        bubble.setBackground(g);
        bubbleLp = newLp(dp(54), dp(54));
        bubbleLp.x = screenW - dp(70);
        bubbleLp.y = screenH / 3;
        bubble.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = bubbleLp.x;
                        sy = bubbleLp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - tx;
                        float dy = e.getRawY() - ty;
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                        if (moved) {
                            bubbleLp.x = clamp(sx + (int) dx, 0, screenW - dp(54));
                            bubbleLp.y = clamp(sy + (int) dy, 0, screenH - dp(54));
                            if (bubbleAttached) wm.updateViewLayout(bubble, bubbleLp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) showPanel();
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable border = new GradientDrawable();
        border.setColor(Color.TRANSPARENT);
        border.setStroke(dp(2), 0xFF1E88E5);
        panel.setBackground(border);

        int pw = (int) (screenW * 0.94f);
        int ph = (int) (screenH * 0.6f);
        panelLp = newLp(pw, ph);
        panelLp.x = (screenW - pw) / 2;
        panelLp.y = (int) (screenH * 0.08f);

        drawing = new DrawingView(this);

        // ---- header (drag handle) ----
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(0xFF1E88E5);
        header.setPadding(dp(8), dp(4), dp(4), dp(4));

        TextView title = new TextView(this);
        title.setText("Rough Work");
        title.setTextColor(Color.WHITE);
        title.setTextSize(14);
        title.setTypeface(null, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        pageLabel = new TextView(this);
        pageLabel.setText("1/1");
        pageLabel.setTextColor(Color.WHITE);
        pageLabel.setTextSize(12);
        pageLabel.setPadding(dp(6), 0, dp(6), 0);
        header.addView(pageLabel);

        header.addView(headerBtn("Tools", v -> {
            toolsBox.setVisibility(toolsBox.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
        }));
        fullBtn = headerBtn("Full", v -> toggleFullscreen());
        header.addView(fullBtn);
        header.addView(headerBtn("Hide", v -> hidePanel()));
        header.addView(headerBtn("Exit", v -> stopEverything()));

        header.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (fullscreen) return true;
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = panelLp.x;
                        sy = panelLp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.x = clamp(sx + (int) (e.getRawX() - tx), -panelLp.width + dp(90), screenW - dp(90));
                        panelLp.y = clamp(sy + (int) (e.getRawY() - ty), 0, screenH - dp(60));
                        updatePanel();
                        return true;
                    default:
                        return true;
                }
            }
        });
        panel.addView(header, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // ---- tools box ----
        toolsBox = new LinearLayout(this);
        toolsBox.setOrientation(LinearLayout.VERTICAL);
        toolsBox.setBackgroundColor(0xFFF5F7FA);

        // row A: tools
        LinearLayout rowA = newRow(toolsBox);
        for (int i = 0; i < TOOL_NAMES.length; i++) {
            final int t = i;
            TextView b = btn(TOOL_NAMES[i], v -> selectTool(t));
            toolBtns.add(b);
            rowA.addView(b);
        }

        // row B: colours
        LinearLayout rowB = newRow(toolsBox);
        for (int i = 0; i < COLORS.length; i++) {
            final int idx = i;
            View sw = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(28), dp(28));
            lp.setMargins(dp(4), dp(2), dp(4), dp(2));
            sw.setLayoutParams(lp);
            sw.setOnClickListener(v -> selectColor(idx));
            swatches.add(sw);
            rowB.addView(sw);
        }

        // row C: size + paper + background transparency
        LinearLayout rowC = new LinearLayout(this);
        rowC.setOrientation(LinearLayout.HORIZONTAL);
        rowC.setGravity(Gravity.CENTER_VERTICAL);
        rowC.setPadding(dp(8), 0, dp(4), 0);
        TextView sizeLbl = new TextView(this);
        sizeLbl.setText("Size");
        sizeLbl.setTextSize(12);
        sizeLbl.setTextColor(0xFF263238);
        rowC.addView(sizeLbl);
        SeekBar sb = new SeekBar(this);
        sb.setMax(30);
        sb.setProgress(5);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                drawing.setBrushLevel(p + 1);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        rowC.addView(sb, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        paperBtn = btn("Plain", v -> paperBtn.setText(drawing.cyclePaper()));
        rowC.addView(paperBtn);
        alphaBtn = btn("Bg 100%", v -> {
            alphaIdx = (alphaIdx + 1) % ALPHAS.length;
            drawing.setPaperAlpha(ALPHAS[alphaIdx]);
            alphaBtn.setText("Bg " + (ALPHAS[alphaIdx] * 100 / 255) + "%");
        });
        rowC.addView(alphaBtn);
        toolsBox.addView(rowC, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // row D: actions
        LinearLayout rowD = newRow(toolsBox);
        rowD.addView(btn("Undo", v -> drawing.undo()));
        rowD.addView(btn("Redo", v -> drawing.redo()));
        TextView clearBtn = btn("Clear", v -> drawing.clearPage());
        clearBtn.setOnLongClickListener(v -> {
            archiveSession(false, false);
            drawing.reset();
            toast("All pages cleared (old work saved in history)");
            return true;
        });
        rowD.addView(clearBtn);
        rowD.addView(btn("+Page", v -> drawing.newPage()));
        rowD.addView(btn("Prev", v -> drawing.prevPage()));
        rowD.addView(btn("Next", v -> drawing.nextPage()));
        rowD.addView(btn("Save", v -> archiveSession(false, true)));

        panel.addView(toolsBox, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // ---- canvas + resize handle ----
        FrameLayout canvasBox = new FrameLayout(this);
        canvasBox.addView(drawing, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        TextView handle = new TextView(this);
        handle.setText("\u25E2");
        handle.setTextSize(18);
        handle.setTextColor(0xFF1E88E5);
        handle.setGravity(Gravity.CENTER);
        handle.setBackground(rounded(0x99FFFFFF, dp(6)));
        handle.setOnTouchListener(new View.OnTouchListener() {
            int w0, h0;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (fullscreen) return true;
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        w0 = panelLp.width;
                        h0 = panelLp.height;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.width = clamp(w0 + (int) (e.getRawX() - tx), dp(240), screenW);
                        panelLp.height = clamp(h0 + (int) (e.getRawY() - ty), dp(220), screenH);
                        updatePanel();
                        return true;
                    default:
                        return true;
                }
            }
        });
        canvasBox.addView(handle, new FrameLayout.LayoutParams(dp(36), dp(36), Gravity.BOTTOM | Gravity.END));
        panel.addView(canvasBox, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        selectTool(Stroke.PEN);
        refreshSwatches();

        drawing.setListener(new DrawingView.Listener() {
            @Override
            public void onChanged() {
                dirty = true;
                handler.removeCallbacks(autosave);
                handler.postDelayed(autosave, 1500);
            }

            @Override
            public void onPageChanged(int index, int count) {
                pageLabel.setText((index + 1) + "/" + count);
                paperBtn.setText(drawing.paperName());
            }
        });
    }

    // ---------- tool / colour selection ----------

    private void selectTool(int t) {
        drawing.setTool(t);
        for (int i = 0; i < toolBtns.size(); i++) {
            toolBtns.get(i).setBackground(rounded(i == t ? 0xFF90CAF9 : 0xFFECEFF1, dp(8)));
        }
    }

    private void selectColor(int idx) {
        selColorIdx = idx;
        drawing.setColor(COLORS[idx]);
        if (drawing.getTool() >= Stroke.ERASER) selectTool(Stroke.PEN);
        refreshSwatches();
    }

    private void refreshSwatches() {
        for (int i = 0; i < swatches.size(); i++) {
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(COLORS[i]);
            boolean sel = i == selColorIdx;
            g.setStroke(sel ? dp(3) : dp(1), sel ? 0xFF1E88E5 : 0xFF90A4AE);
            swatches.get(i).setBackground(g);
        }
    }

    // ---------- window management ----------

    private void updatePanel() {
        if (panelAttached) {
            try {
                wm.updateViewLayout(panel, panelLp);
            } catch (Exception ignored) {
            }
        }
    }

    private void toggleFullscreen() {
        if (!fullscreen) {
            savedX = panelLp.x;
            savedY = panelLp.y;
            savedW = panelLp.width;
            savedH = panelLp.height;
            panelLp.x = 0;
            panelLp.y = 0;
            panelLp.width = screenW;
            panelLp.height = screenH;
            fullscreen = true;
            fullBtn.setText("Restore");
        } else {
            panelLp.x = savedX;
            panelLp.y = savedY;
            panelLp.width = savedW;
            panelLp.height = savedH;
            fullscreen = false;
            fullBtn.setText("Full");
        }
        updatePanel();
    }

    private void showBubble() {
        if (!bubbleAttached) {
            try {
                wm.addView(bubble, bubbleLp);
                bubbleAttached = true;
            } catch (Exception ignored) {
            }
        }
    }

    private void showPanel() {
        if (bubbleAttached) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubbleAttached = false;
        }
        if (!panelAttached) {
            try {
                wm.addView(panel, panelLp);
                panelAttached = true;
            } catch (Exception ignored) {
            }
        }
    }

    private void hidePanel() {
        saveCurrent();
        if (panelAttached) {
            try {
                wm.removeView(panel);
            } catch (Exception ignored) {
            }
            panelAttached = false;
        }
        showBubble();
    }

    private void removeViews() {
        if (panelAttached) {
            try {
                wm.removeView(panel);
            } catch (Exception ignored) {
            }
            panelAttached = false;
        }
        if (bubbleAttached) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubbleAttached = false;
        }
    }

    // ---------- saving ----------

    private void saveCurrent() {
        if (drawing == null) return;
        try {
            if (drawing.hasContent()) StorageManager.saveCurrent(this, drawing.toJson().toString());
            else StorageManager.clearCurrent(this);
        } catch (Exception ignored) {
        }
    }

    private void archiveSession(boolean sync, final boolean showToast) {
        if (drawing == null || !drawing.hasContent()) {
            if (showToast) toast("Nothing to save yet");
            return;
        }
        final String json;
        try {
            json = drawing.toJson().toString();
        } catch (Exception e) {
            return;
        }
        final ArrayList<Bitmap> bmps = drawing.renderAllPages();
        dirty = false;
        Runnable job = new Runnable() {
            @Override
            public void run() {
                StorageManager.saveSession(OverlayService.this, json, bmps);
                for (Bitmap b : bmps) b.recycle();
                if (showToast) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            toast("Saved to history (kept for 90 days)");
                        }
                    });
                }
            }
        };
        if (sync) job.run();
        else new Thread(job).start();
    }

    private void stopEverything() {
        handler.removeCallbacks(autosave);
        if (drawing != null && dirty && drawing.hasContent()) {
            archiveSession(true, false);
        }
        StorageManager.clearCurrent(this);
        removeViews();
        stopForeground(Service.STOP_FOREGROUND_REMOVE);
        stopSelf();
    }
}
